Shell script para correr testes a um projecto de ORTOGRAFIA.
Deve ser desarquivado para a pasta onde está o executável a testar.
Caso o script "run_test" seja corrido sem argumentos na linha de comando, usa o modo 1 e stdin/stdout
Pode ser corrido com o modo de funcionamento como 1º parâmetro na linha de comando,
ou seja:
correr no modo de funcionamento 1
./run_test
correr no modo de funcionamento 2
./run_test 2
correr no modo de funcionamento 3
./run_test 3

